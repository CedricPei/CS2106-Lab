#include <semaphore.h>
#include <stdlib.h>
#include <stdio.h>
#include "packer.h"
#define RED 1
#define GREEN 2 
#define BLUE 3

struct PACK 
{    
    int *ls;
    int packing;
    int packed; 
    sem_t pack_mutex; 
};

void pack_init(struct PACK *area, sem_t *access);
void wait_init(sem_t *wait);
void my_destroy(struct PACK *area, sem_t *access, sem_t *wait);
void get_id(int **ptr, int id, int *other_ids);

int N;
struct PACK red_pack;
struct PACK green_pack;
struct PACK blue_pack;
sem_t r_access;
sem_t g_access;
sem_t b_access;
sem_t r_wait;
sem_t g_wait;
sem_t b_wait;

void packer_init(int pack_num) {
    N = pack_num;

    pack_init(&red_pack, &r_access);
    pack_init(&green_pack, &g_access);
    pack_init(&blue_pack, &b_access);
    wait_init(&r_wait);
    wait_init(&g_wait);
    wait_init(&b_wait);    
}

void packer_destroy(void) {
    my_destroy(&red_pack, &r_access, &r_wait);
    my_destroy(&green_pack, &g_access, &g_wait);
    my_destroy(&blue_pack, &b_access, &b_wait);
}

void pack_ball(int colour, int id, int *other_ids) {
    if (colour == RED)
    {         
        sem_wait(&r_wait); 
        sem_wait(&r_access);

        red_pack.ls[red_pack.packing] = id;
        red_pack.packing++;        
        if (red_pack.packing == N) 
        {          
            sem_post(&(red_pack.pack_mutex));
            sem_post(&r_access);
            sem_wait(&(red_pack.pack_mutex));
            sem_wait(&r_access);
            get_id(&(red_pack.ls), id, other_ids);
            red_pack.packed++;            
        } 
        else
        {                        
            sem_post(&r_access);
            sem_wait(&(red_pack.pack_mutex));            
            sem_wait(&r_access);
            get_id(&(red_pack.ls), id, other_ids);
            red_pack.packed++;
        }

        if (red_pack.packed == N) 
        {                    
            pack_init(&red_pack, &r_access);
            for (int i=0; i<N; i++) 
            {
                sem_post(&r_wait);
            }
        }
        else
        {
            sem_post(&(red_pack.pack_mutex));
        }
        sem_post(&r_access);           
    } 
    else if (colour == GREEN) 
    {
        sem_wait(&g_wait); 
        sem_wait(&g_access);
        green_pack.ls[green_pack.packing] = id;
        green_pack.packing++;        
        if (green_pack.packing == N) 
        {          
            sem_post(&(green_pack.pack_mutex));
            sem_post(&g_access);
            sem_wait(&(green_pack.pack_mutex));
            sem_wait(&g_access);
            get_id(&(green_pack.ls), id, other_ids);
            green_pack.packed++;            
        } 
        else
        {                        
            sem_post(&g_access);
            sem_wait(&(green_pack.pack_mutex));            
            sem_wait(&g_access);
            get_id(&(green_pack.ls), id, other_ids);
            green_pack.packed++;
        }

        if (green_pack.packed == N)
        {                    
            pack_init(&green_pack, &g_access);
            for (int i=0; i<N; i++) 
            {
                sem_post(&g_wait);
            }
        } 
        else 
        {
            sem_post(&(green_pack.pack_mutex));
        }
        sem_post(&g_access);          
    }
    else
    { 
        sem_wait(&b_wait); 
        sem_wait(&b_access);

        blue_pack.ls[blue_pack.packing] = id;
        blue_pack.packing++;        
        if (blue_pack.packing == N)
        {          
            sem_post(&(blue_pack.pack_mutex));
            sem_post(&b_access);
            sem_wait(&(blue_pack.pack_mutex));
            sem_wait(&b_access);
            get_id(&(blue_pack.ls), id, other_ids);
            blue_pack.packed++;            
        }
        else
        {                        
            sem_post(&b_access);
            sem_wait(&(blue_pack.pack_mutex));            
            sem_wait(&b_access);
            get_id(&(blue_pack.ls), id, other_ids);
            blue_pack.packed++;
        }

        if (blue_pack.packed == N) 
        {                    
            pack_init(&blue_pack, &b_access);
            for (int i=0; i<N; i++)
            {
                sem_post(&b_wait);
            }
        }
        else
        {
            sem_post(&(blue_pack.pack_mutex));
        }
        sem_post(&b_access);           
    }            
}

void get_id(int **ptr, int id, int *other_ids) {    
    int count = 0;

    for (int i=0; i<N; i++) 
    {
        if ((*ptr)[i] != id) 
        {
            other_ids[count] = (*ptr)[i];
            count++;
        }
    }        
}

void pack_init(struct PACK *area, sem_t *access) {
    area->ls = malloc(sizeof(int) * N);
    area->packing = 0;
    area->packed = 0;
    sem_init(&(area->pack_mutex), 0, 0);
    sem_init(access, 0, 1);
}

void wait_init(sem_t *wait) {
    sem_init(wait, 0, N);
}

void my_destroy(struct PACK *area, sem_t *access, sem_t *wait) {
    free(area->ls);
    sem_destroy(&(area->pack_mutex));
    sem_destroy(access);
    sem_destroy(wait);
}